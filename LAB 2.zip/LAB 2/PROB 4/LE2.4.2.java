public class one{
    one(int x)
    {
        
        System.out.println("Entered integer "+x);
    }
}
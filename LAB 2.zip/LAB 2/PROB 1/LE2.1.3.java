public class child extends mother{
  
}
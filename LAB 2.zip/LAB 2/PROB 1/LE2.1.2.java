public class mother
{
        public static void show()
        {
            int x;
            System.out.println("hello");
        }
        
  
}
class Kauravas extends Bharatvanshi{
    void kind()
    {
        System.out.println("KAURAVAS UNKIND");
    }
    void obey()
    {
        System.out.println("KAURAVAS DISOBEY");
    }
}
class Duck{
    public void swim()
    {
        System.out.println("I can swim");
    }
}
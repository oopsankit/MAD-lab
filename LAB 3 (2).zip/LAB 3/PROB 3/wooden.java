class Wooden_duck extends Duck{
    
}
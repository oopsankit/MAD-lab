interface quackable{
    void quack();
}
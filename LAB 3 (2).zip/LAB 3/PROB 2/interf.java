interface Testable{
    void display();
}